@extends('adminlte::page')

@section('title', 'Analisis Clinico')

@section('content_header')
    <div>
        <h4></h4>
    </div>
@stop

@section('content')

@stop
