<?php $__env->startSection('title', 'Editar Tipo Seguro'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center ">
        <div class="col-md-8 mt-4">
            <div class="card">
                <div class="card-header">Editar Tipo Seguro</div>
                <div class="card-body">
                    <form action="<?php echo e(route('tiposeguro.update', $tiposeguro->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label for="descripcion">Descripción:</label>
                            <input type="text" class="form-control" id="descripcion" name="descripcion" value="<?php echo e($tiposeguro->descripcion); ?>">
                        </div>
                        <div class="form-group">
                            <label for="descuento">Descuento:</label>
                            <input type="number" class="form-control" id="descuento" name="descuento" value="<?php echo e($tiposeguro->descuento); ?>">
                        </div>
                        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                        <a href="#" class="btn btn-secondary">Cancelar</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lab_clinico\resources\views/VistaTipoSeguro/edit.blade.php ENDPATH**/ ?>