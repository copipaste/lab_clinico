<?php $__env->startSection('title', 'Analisis Clinico'); ?>

<?php $__env->startSection('content_header'); ?>
    <div>
        <h4></h4>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lab_clinico\resources\views/welcome.blade.php ENDPATH**/ ?>