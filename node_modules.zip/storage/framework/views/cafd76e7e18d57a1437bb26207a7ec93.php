<div class="max-w-7x1 mx-auto px-4 sm:px-6 lg:px-8 text-red-500">
    <?php echo e($slot); ?>

</div><?php /**PATH C:\xampp\htdocs\lab_clinico\resources\views/components/alert.blade.php ENDPATH**/ ?>