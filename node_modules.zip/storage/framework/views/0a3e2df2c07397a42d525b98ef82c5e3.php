<?php $__env->startSection('title', 'Editar Rol'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar Rol</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('roles.update', $role)); ?>" method="POST">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nombre">Nombre del Rol:</label>
                    <input type="text" class="form-control" id="nombre" name="nombre" value="<?php echo e($role->name); ?>" required>
                </div>
                <div class="form-group">
                    <label for="permisos">Permisos:</label>
                    <div class="row">
                        <?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="permisos[]" value="<?php echo e($permiso->id); ?>" <?php echo e($role->permissions->contains($permiso->id) ? 'checked' : ''); ?>>
                                        <?php echo e($permiso->name); ?>

                                    </label>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <!-- Botones para enviar o cancelar la edición -->
                <div class="row">
                    <div class="col-md-6">
                        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                        
                        <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-secondary">Cancelar</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lab_clinico\resources\views/roles/edit.blade.php ENDPATH**/ ?>