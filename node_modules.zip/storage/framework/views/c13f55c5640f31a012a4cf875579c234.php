<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">PACIENTES</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">
            <p><strong>Carnet de Identidad:</strong> <?php echo e($paciente->ci); ?></p>
            <p><strong>Nombre:</strong> <?php echo e($paciente->nombre); ?></p>
            <p><strong>Fecha de Nacimiento:</strong> <?php echo e($paciente->fechaNacimiento); ?></p>
            <p><strong>Sexo:</strong> <?php echo e($paciente->sexo); ?></p>
            <p><strong>Telefono:</strong> <?php echo e($paciente->telefono); ?></p>
            <p><strong>Correo Electronico:</strong> <?php echo e($paciente->user->email); ?></p>
            <p><strong>Tipo de Seguro:</strong> <?php echo e($paciente->tipoSeguro->descripcion); ?></p>
        </div>
    </div>

    <div class="form-group mt-2">
        <a href="<?php echo e(route('pacientes.edit', $paciente)); ?>" class="btn btn-primary">Editar</a>
        <a href="<?php echo e(route('pacientes.index')); ?>" class="btn btn-danger">Cancelar</a>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lab_clinico\resources\views/pacientes/show.blade.php ENDPATH**/ ?>