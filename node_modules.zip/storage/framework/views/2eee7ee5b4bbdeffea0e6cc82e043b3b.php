<table class="min-w-full bg-white">
    <thead>
        <tr>
            <th class="py-2 px-4 border-b">Id</th>
            <th class="py-2 px-4 border-b">IP</th>
            <th class="py-2 px-4 border-b">Nombre Usuario</th>
            <th class="py-2 px-4 border-b">Actividad</th>
            <th class="py-2 px-4 border-b">Fecha</th>
        </tr>
    </thead>
    <tbody>
        <!-- Se agrega la clase 'activity-row' a cada fila -->
        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="activity-row">
                <td class="py-2 px-4 border-b text-center"><?php echo e($activity->id); ?></td>
                <td class="py-2 px-4 border-b text-center"><?php echo e($activity->properties); ?></td>
                <td class="py-2 px-4 border-b text-center">
                    <?php if($activity->causer): ?>
                        <?php echo e($activity->causer->name); ?>

                    <?php else: ?>
                        Usuario no disponible
                    <?php endif; ?>
                </td>
                <td class="py-2 px-4 border-b text-center"><?php echo e($activity->description); ?></td>
                <td class="py-2 px-4 border-b text-center"><?php echo e($activity->created_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\lab_clinico\resources\views/VistaBitacora/activities_table.blade.php ENDPATH**/ ?>